<?php
/**
 * (c) king-theme.com
 */
?>
	<form method="get" id="" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<input type="text" class="field" name="s" id="s" placeholder="<?php esc_html_e( 'keyword...', 'universe' ); ?>" />
		<button></button>
	</form>
