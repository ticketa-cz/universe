jQuery(document).ready(function(){
	
	/*
	 *
	 * universe_options_date function
	 * Adds datepicker js
	 *
	 */
	jQuery('.nhp-opts-datepicker').datepicker();
	
});