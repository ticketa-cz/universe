<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $universe, $post, $more;

//get_header();

do_action('test_mod');

//get_footer();
?>
