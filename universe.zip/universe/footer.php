<?php
/**
 * 	(c) king-theme.com
 */

 	universe::get_footer();

	/*
		. change footer via theme-panel
		. http://you-site-url/wp-admin/edit.php?post_type=universe_footer
	*/

?>



	</div><!-- #main -->

	<?php wp_footer(); ?>


</body>
</html>