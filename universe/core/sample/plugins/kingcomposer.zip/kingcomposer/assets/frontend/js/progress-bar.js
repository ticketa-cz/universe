/***
 * Progress bars
 * (c) king-theme.Com
 ***/

(function($){
  // Simple wrapper around jQuery animate to simplify animating progress from your app
  // Inputs: Progress as a percent, Callback
  // TODO: Add options and jQuery UI support.
  $.fn.animateProgress = function( progress, callback ) {
    return this.each(function() {
        $(this).animate({
            width: progress+'%'
        }, {
        duration: 2000,

        // swing or linear
        easing: 'swing',

        // this gets called every step of the animation, and updates the label
        step: function( progress ){
            var labelEl = $('.ui-label', this),
                valueEl = $('.value', labelEl);

            if( Math.ceil(progress) < 20 && $('.ui-label', this).is(":visible") ) {
                labelEl.hide();
            }else{
                if (labelEl.is(":hidden")) {
                    labelEl.fadeIn();
                }
            }

            valueEl.text(Math.ceil(progress) + '%');
        },
        complete: function(scope, i, elem) {
            if (callback) {
                callback.call(this, i, elem );
            }
        }
      });
    });
  };
})(jQuery);
